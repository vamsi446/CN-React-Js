import React from 'react';
import './css/screen.css';


class Screen extends React.Component{

// Display the sidemenu, coverflow, games,Music etc here
  render(){

    return (
      <></>
    );
  }

}

export default Screen;

